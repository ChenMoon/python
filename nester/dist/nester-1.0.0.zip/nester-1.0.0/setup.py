from  distutils.core import setup

setup(
    name = 'nester',
    version = '1.0.0',
    py_modules = ['nester'],
    author = 'Moon',
    author_email = 'hfpython@headfirstlabs.com',
    url = 'http://www.headfirstlabs.com/',
    description = 'A simple printer of nested lists'
)